import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import {AgGridModule} from 'ag-grid-angular';
import {FormsModule} from '@angular/forms';

import { AppComponent } from './app.component';
import { ZiptoDestComponent } from './zipto-dest/ziptodest.component';

import {HttpClientModule} from '@angular/common/http';
import { AppRoutingModule } from './/app-routing.module';
import { ZiptodestService } from './service/ziptodest.service';

@NgModule({
  declarations: [
    AppComponent,
    ZiptoDestComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule,
    AgGridModule.withComponents([]),
    NgbModule.forRoot(),
    AppRoutingModule
  ],
  providers: [ZiptodestService],
  bootstrap: [AppComponent]
})
export class AppModule { }
