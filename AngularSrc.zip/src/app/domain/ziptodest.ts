export class ZipToDest {
    network: string;
    country:number;
    zipcode:number;
    state:string;
    destinationTerminal:string;
    creationDate:string;
    creationUser:string;
    effectiveDate:string;
    processed:boolean;
}