import { TestBed, inject } from '@angular/core/testing';

import { ZiptodestService } from './ziptodest.service';

describe('ZiptodestService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ZiptodestService]
    });
  });

  it('should be created', inject([ZiptodestService], (service: ZiptodestService) => {
    expect(service).toBeTruthy();
  }));
});
