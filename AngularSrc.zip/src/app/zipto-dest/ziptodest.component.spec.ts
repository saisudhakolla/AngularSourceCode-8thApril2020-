import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ZiptoDestComponent } from './ziptodest.component';

describe('ZiptoDestComponent', () => {
  let component: ZiptoDestComponent;
  let fixture: ComponentFixture<ZiptoDestComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ZiptoDestComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ZiptoDestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
