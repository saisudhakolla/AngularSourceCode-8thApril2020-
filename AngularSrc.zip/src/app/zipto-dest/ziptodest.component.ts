import { Component, OnInit } from '@angular/core';
import { ZiptodestService } from '../service/ziptodest.service';
import { ZipToDest } from '../domain/ziptodest';
import { Observable } from "rxjs";


@Component({
  selector: 'app-zipto-dest',
  templateUrl: './ziptodest.component.html',
  styleUrls: ['./ziptodest.component.css']
})
export class ZiptoDestComponent implements OnInit {

  private gridApi;
  private searchValue;

  columnDefs = [
    {headerName: 'Network', field: 'network',width: 100, },
    {headerName: 'Country code', field: 'country',width: 120 },
    {headerName: 'Zip / Postal Code', field: 'zipcode',sortable: true,width: 170},
    {headerName: 'State / Province', field: 'state',width: 130},
    {headerName: 'Destination', field: 'destinationTerminal',width: 120},
    {headerName: 'Effective Date', field: 'creationDate',width: 120},
    {headerName: 'Created By', field: 'creationUser',width: 120},
    {headerName: 'Creation Date', field: 'effectiveDate',width: 120},
    {headerName: 'Processed', field: 'processed',width: 120}
  ];

    rowData: Observable<ZipToDest[]>;

    constructor(private dataService:ZiptodestService) {

    }

    onGridReady(params) {
      this.gridApi=params.api;
    }  
 
    ngOnInit() {
      this.reloadData();
    }

    reloadData() {
     this.dataService.getData()
     .subscribe(
      data => this.rowData = data);
    }

    quickSearch(){
      this.gridApi.setQuickFilter(this.searchValue);
    }

    exportDataAsCsv(){
      var params = {
       fileName: 'ZipToDest'
      };
      this.gridApi.exportDataAsCsv(params);
    }

}
