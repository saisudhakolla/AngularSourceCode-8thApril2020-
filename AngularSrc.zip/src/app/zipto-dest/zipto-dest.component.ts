import { Component, OnInit } from '@angular/core';
import {HttpClient} from '@angular/common/http';


@Component({
  selector: 'app-zipto-dest',
  templateUrl: './zipto-dest.component.html',
  styleUrls: ['./zipto-dest.component.css']
})
export class ZiptoDestComponent implements OnInit {

  columnDefs = [
    {headerName: 'Network', field: 'network',width: 100, },
    {headerName: 'Country code', field: 'country',width: 120 },
    {headerName: 'Zip / Postal Code', field: 'zipcode',sortable: true,width: 150},
    {headerName: 'State / Province', field: 'state',width: 130},
    {headerName: 'Destination', field: 'destinationTerminal',width: 120},
    {headerName: 'Effective Date', field: 'creationDate',width: 120},
    {headerName: 'Created By', field: 'creationUser',width: 120},
    {headerName: 'Creation Date', field: 'effectiveDate',width: 120},
    {headerName: 'Processed', field: 'processed',width: 120}
];

rowData: any;

constructor(private http: HttpClient) {

}
ngOnInit() {
  this.rowData = this.http.get('getGridData');
}

}
