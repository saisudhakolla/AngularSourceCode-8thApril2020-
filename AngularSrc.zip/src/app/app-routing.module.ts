import { NgModule } from '@angular/core';
import {RouterModule,Routes} from '@angular/router';
import { ZiptoDestComponent } from './zipto-dest/ziptodest.component';


const appRoutes:Routes = [
 
  {path:'',redirectTo:'ZiptoDest', pathMatch:'full'},
  {path:'ZiptoDest', component:ZiptoDestComponent}
];

@NgModule({
  imports: [
    RouterModule.forRoot(appRoutes) 
  ],
  exports:[RouterModule]
})
export class AppRoutingModule { }
